//
//  JokeCell.swift
//  TableWithUserDefault
//
//  Created by admin on 03/10/24.
//

import UIKit

class JokeCell: UITableViewCell {

    @IBOutlet weak var jokelbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
