//
//  DetailVC.swift
//  Weather_App
//
//  Created by admin on 09/08/24.
//

import UIKit

class DetailVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
